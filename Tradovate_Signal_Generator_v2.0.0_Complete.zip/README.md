# Tradovate Signal Generator - Go Edition

High-performance trading signal generator written in Go. This is the distribution edition designed for customer deployment with subscription-based ML model access.

## 🚀 Features

- **High Performance**: Go-based architecture for low-latency signal generation
- **Subscription ML Models**: Access to trained models requires valid license
- **Standalone Trading**: Direct API execution without browser dependency ✅
- **Real-time Processing**: Processes live market data from Tradovate API
- **Discord Integration**: Complete logging and debugging via Discord webhooks
- **Professional Risk Management**: Built-in kill switches and position sizing
- **Cross-Platform**: Runs on Windows, macOS, and Linux

## 🤖 Deployment Modes

### 1. Standalone Mode ✅ (Recommended for Production)
- **No browser required** - Pure Go application
- **Direct API trading** via Tradovate REST API
- **Discord logging** for debugging and monitoring
- **Automatic signal execution** with position management

### 2. Extension Mode
- **Browser integration** via Chrome extension
- **WebSocket communication** with trading UI
- **Manual signal review** and execution

## 📋 Requirements

### Standalone Mode
- Go 1.21 or later
- Valid Tradovate account (demo or live)  
- License token for ML model access
- Discord webhook URL for logging

### Extension Mode
- All of the above, plus:
- Compatible Chrome extension

## 🛠️ Installation

1. **Clone or extract** the signal generator to your desired directory

2. **Install dependencies:**
```bash
go mod download
```

3. **Create configuration:**
```bash
cp .env.example .env
# Edit .env with your credentials
```

4. **Build the application:**
```bash
go build -o tradovate-signal-gen main.go
```

## ⚙️ Configuration

### Required Settings

Edit `.env` file with your credentials:

```bash
# Tradovate API
TRADOVATE_ENV=demo  # or 'live' for production
TRADOVATE_USERNAME=your_username
TRADOVATE_PASSWORD=your_password
TRADOVATE_APP_ID=your_app_id
TRADOVATE_CID=your_cid
TRADOVATE_SECRET=your_secret

# License (required for ML models)
LICENSE_TOKEN=your_license_token

# Symbol (update quarterly)
SIGNAL_GEN_PRIMARY_SYMBOL=MNQM6

# Discord webhook (for standalone mode)
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_WEBHOOK_URL
```

### Mode-Specific Configuration

#### Standalone Mode
- **Discord Webhook**: Required for logging and debugging
- **No WebSocket**: Connects directly to Tradovate API
- **Automatic Trading**: Executes signals immediately

#### Extension Mode  
- **WebSocket Server**: Runs on `127.0.0.1:8765` by default
- **Browser Connection**: Chrome extension connects for:
  - Receiving trading signals
  - Sending real-time price data
  - Exchanging debug information

For security, the WebSocket server only binds to localhost unless a `SIGNAL_GEN_TOKEN` is set.

## 🏃‍♂️ Running

### Standalone Mode (Recommended)
```bash
# Set up Discord webhook in .env first
echo "DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_URL" >> .env

# Run standalone bot
./tradovate-signal-gen

# The bot will:
# ✅ Load historical data from Tradovate API
# ✅ Generate signals using ML models 
# ✅ Execute trades automatically
# ✅ Log everything to Discord for debugging
```

### Extension Mode
```bash
# Start the WebSocket server for browser extension
./tradovate-signal-gen

# Then open Chrome extension and connect to localhost:8765
```

### Debug Mode
```bash
SIGNAL_GEN_LOG=DEBUG ./tradovate-signal-gen
```

### Background Mode (Linux/macOS)
```bash
nohup ./tradovate-signal-gen > signal_gen.log 2>&1 &
```

## 📊 Signal Generation

### Scorecard System

The signal generator uses a multi-component scorecard:

- **SC-01 Risk Control**: Session limits and kill switches
- **SC-02 Macro Bias**: Market direction bias (ML model)
- **SC-03 Micro Entry**: Entry timing optimization (ML model)
- **Regime Detection**: Market state classification

### Signal Types

- **B30**: Buy signal (bullish bias)
- **S70**: Sell signal (bearish bias)
- **BX/SX**: Exit signals

### Position Sizing

Automatic position sizing based on:
- Composite score strength
- Current volatility (ATR)
- Risk management rules
- Account size considerations

## 🔒 License & ML Models

### Subscription Required

ML models (SC-02, SC-03) require an active license. Without a valid license:
- Signal generator runs in basic mode
- Uses simplified technical indicators
- Limited signal accuracy

### License Verification

The system checks license status:
- On startup
- Every 30 minutes during operation
- Against secure license server

## 🌐 Browser Extension Integration

The signal generator communicates with the browser extension via WebSocket:

### Message Types

- **Signals**: `{"type":"predict","data":{"signal":"B30",...}}`
- **Debug**: `{"type":"debug","data":{"regime":"R4",...}}`
- **Heartbeat**: `{"type":"pong"}` (response to ping)

### Security

- Authentication via shared token (if configured)
- Localhost-only binding by default
- Constant-time token comparison

## 📈 Performance

### Optimizations

- Concurrent tick processing
- Efficient candle aggregation
- Minimal memory allocation
- Fast indicator calculations

### Resource Usage

- **Memory**: ~50-100MB typical
- **CPU**: Low usage except during calculations
- **Network**: Minimal (API calls + WebSocket)

## 🔧 Troubleshooting

### Common Issues

1. **License Invalid**
   - Check LICENSE_TOKEN in .env
   - Verify license server connectivity
   - Confirm subscription status

2. **API Authentication Failed**
   - Verify Tradovate credentials
   - Check app registration
   - Ensure API password is enabled

3. **Extension Not Connecting**
   - Verify port 8765 is free
   - Check SIGNAL_GEN_WS_PORT setting
   - Reload browser extension

4. **No Signals Generated**
   - Check minimum bars requirement
   - Verify ML models loaded (if licensed)
   - Review composite score vs threshold

### Debug Mode

Enable debug logging for detailed information:
```bash
SIGNAL_GEN_LOG=DEBUG ./tradovate-signal-gen
```

## 📂 File Structure

```
GO_bot/
├── main.go              # Application entry point
├── config/              # Configuration management
├── engine/              # Core signal generation
├── tradovate/           # API client
├── server/              # WebSocket server
├── license/             # License verification
├── models/              # ML model management
├── indicators/          # Technical indicators
├── candles/             # Candle aggregation
├── types/               # Data structures
└── .env.example         # Configuration template
```

## 🚨 Risk Warning

**This software is for educational and research purposes. Trading involves substantial risk of loss. Past performance does not guarantee future results. Use at your own risk.**

## 📞 Support

For technical support and license inquiries:
- Documentation: See README files
- License Issues: Contact your provider
- Bug Reports: Check logs with DEBUG mode

## 🔄 Updates

To update the signal generator:
1. Stop the running process
2. Replace executable with new version
3. Review configuration changes
4. Restart with new version

---

**© 2026 Signal Gen Pro - Distribution Edition**