# SQLite Database Integration

## 📊 Database Features

The Go signal generator includes SQLite integration for:

- **Signal History**: All generated signals with scores and outcomes
- **Trade Records**: Execution history with order details
- **Candle Data**: Historical price data storage  
- **Session Statistics**: Daily P&L, trade counts, position tracking

## 🏗️ Database Schema

### Tables Created

```sql
-- Trading signals with ML scores
signals (id, symbol, direction, signal_type, price, confidence, 
         contracts, stop_loss, take_profit, regime, sc01_risk, 
         sc02_bias, sc03_entry, composite, threshold, timestamp)

-- Trade executions
trades (signal_id, order_id, symbol, side, quantity, price, 
        status, executed_at)

-- Price candles
candles (symbol, timestamp, open, high, low, close, volume, bar_index)

-- Daily session stats
session_stats (session_date, trades_today, session_pnl, position_side,
               equity, peak_equity, trailing_low, kill_switch_tripped)
```

## ⚙️ Requirements

**For SQLite Support:**
- CGO enabled during compilation
- C compiler available (GCC on Windows/Linux, Clang on macOS)

**Current Distribution:**
- SQLite code included but requires CGO to function
- Bot runs without database if CGO unavailable
- Graceful fallback with warning message

## 🔧 Building with SQLite

### Windows (with MinGW-w64)
```bash
# Install TDM-GCC or MinGW-w64
# Add to PATH: C:\TDM-GCC-64\bin

CGO_ENABLED=1 go build -o tradovate-signal-gen.exe .
```

### Linux
```bash
# Install GCC
sudo apt install build-essential

CGO_ENABLED=1 go build -o tradovate-signal-gen .
```

### macOS
```bash
# Xcode command line tools required
xcode-select --install

CGO_ENABLED=1 go build -o tradovate-signal-gen .
```

## 🎯 Current Status

**✅ Code Ready**: Database integration fully implemented
**⚠️ Distribution**: Requires CGO for SQLite functionality
**✅ Fallback**: Graceful operation without database

## 📈 Benefits with SQLite

When enabled, SQLite provides:
- **Performance Analysis**: Historical signal accuracy
- **Session Recovery**: Resume after restarts
- **Audit Trail**: Complete trade history
- **Backtesting Data**: Accumulated market data

## 🔄 Future Enhancements

- **Performance Reports**: Win rate, Sharpe ratio calculation
- **Signal Analysis**: ML model accuracy tracking  
- **Risk Metrics**: Drawdown analysis and reporting
- **Data Export**: CSV export for external analysis

---

*Note: The bot operates fully without SQLite - database is optional for enhanced features.*