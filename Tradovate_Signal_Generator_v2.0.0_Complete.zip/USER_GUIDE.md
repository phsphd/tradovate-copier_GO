# Tradovate Signal Generator - User Guide

**Go Edition v2.0.0 - Standalone Trading Bot**

---

## 📖 Table of Contents

1. [Quick Start](#quick-start)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Operation Modes](#operation-modes)
5. [Discord Setup](#discord-setup)
6. [Trading Features](#trading-features)
7. [Monitoring & Debugging](#monitoring--debugging)
8. [Troubleshooting](#troubleshooting)
9. [Support](#support)

---

## 🚀 Quick Start

The Tradovate Signal Generator is a professional trading bot that:
- **Generates ML-powered trading signals** using advanced algorithms
- **Executes trades automatically** via Tradovate API
- **Operates standalone** without requiring a browser
- **Logs everything to Discord** for real-time monitoring

### 5-Minute Setup

1. **Extract** the distribution package
2. **Configure** your credentials in `.env`
3. **Setup** Discord webhook for logging
4. **Run** the bot: `./tradovate-signal-gen.exe`

---

## 💾 Installation

### System Requirements

- **Windows 10+** (64-bit)
- **512MB RAM** minimum
- **Stable internet** connection
- **Tradovate account** (demo or live)

### Files Included

```
tradovate-signal-gen/
├── tradovate-signal-gen.exe    # Main application
├── .env.example                # Configuration template
├── README.md                   # Technical documentation
├── USER_GUIDE.pdf             # This guide (PDF format)
└── DEPLOYMENT.md              # Advanced deployment options
```

### Installation Steps

1. **Extract** the zip file to your desired location
2. **Navigate** to the extracted folder
3. **Copy** `.env.example` to `.env`
4. **Edit** `.env` with your credentials (see Configuration section)

---

## ⚙️ Configuration

### Required Credentials

You'll need the following from Tradovate:

#### 1. Tradovate API Credentials

1. Visit https://api.tradovate.com
2. Register your application
3. Note your **App ID**, **CID**, and **Secret**
4. Enable **"API Password"** in your account settings
5. Use your **API password** (not web login password)

#### 2. License Token

- Purchase subscription at https://aiprediction.us
- Your license token enables ML models

#### 3. Discord Webhook (Optional but Recommended)

- Create webhook in your Discord server
- Used for real-time logging and alerts

### Configuration File (.env)

```bash
# ─── Tradovate API ─────────────────────────────
TRADOVATE_ENV=demo                    # "demo" or "live"
TRADOVATE_USERNAME=your_username
TRADOVATE_PASSWORD=your_api_password  # API password, not web password!
TRADOVATE_APP_ID=your_app_id
TRADOVATE_CID=your_cid
TRADOVATE_SECRET=your_secret

# ─── Symbol Configuration ──────────────────────
SIGNAL_GEN_PRIMARY_SYMBOL=MNQM6      # Update quarterly (MNQ, ES, etc.)

# ─── License ────────────────────────────────────
LICENSE_TOKEN=your_license_token      # Required for ML models

# ─── Discord Logging ────────────────────────────
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_URL

# ─── Trading Parameters ─────────────────────────
SIGNAL_GEN_LOG=INFO                  # DEBUG, INFO, WARN, ERROR
MIN_BARS_BEFORE_TRADING=5            # Bars to load before trading
```

---

## 🤖 Operation Modes

### Standalone Mode (Default)

✅ **Fully autonomous trading bot**
- Direct API connection to Tradovate
- Automatic signal generation and execution
- No browser or extension required
- Discord logging for monitoring

### Features in Standalone Mode

- **Historical Data Loading**: 200 candles on startup
- **Real-time Signal Generation**: ML models + technical analysis
- **Automatic Trade Execution**: Market orders via API
- **Position Management**: Stop-loss and take-profit
- **Risk Controls**: Session limits and kill switches
- **Discord Logging**: Every trade, signal, and debug data

---

## 💬 Discord Setup

Discord integration provides real-time monitoring and debugging.

### Creating a Discord Webhook

1. **Open Discord** and select your server
2. **Right-click** on a channel → **Edit Channel**
3. **Go to Integrations** → **Webhooks** → **New Webhook**
4. **Name** your webhook (e.g., "Trading Bot")
5. **Copy Webhook URL**
6. **Paste URL** into `.env` file as `DISCORD_WEBHOOK_URL`

### What You'll See in Discord

The bot sends detailed messages for:

#### 🚀 System Status
- Startup notifications
- License verification
- Connection status
- Heartbeat messages every 5 minutes

#### 📡 Trading Signals
- Signal type (B30, S70)
- Symbol, price, confidence
- Position size and risk levels
- Stop-loss and take-profit levels

#### 📊 Debug Data (Every Minute)
- Current price and market regime
- ML model scores (SC-01, SC-02, SC-03)
- Composite score vs threshold
- Whether signal was triggered

#### 💰 Trade Executions
- Order confirmations
- Fill notifications
- Position updates
- P&L tracking

#### ❌ Error Alerts
- API connection issues
- Order failures
- License problems

---

## 📊 Trading Features

### Signal Generation

The bot uses a sophisticated multi-component system:

#### Scorecard Components

- **SC-01 Risk Control**: Session limits, daily P&L, kill switches
- **SC-02 Macro Bias**: Market direction (ML model, subscription required)
- **SC-03 Micro Entry**: Entry timing optimization (ML model)
- **Regime Detection**: Market volatility and trend classification

#### Signal Types

- **B30**: Buy signal (bullish bias detected)
- **S70**: Sell signal (bearish bias detected)
- **BX/SX**: Exit signals (position closing)

#### Position Sizing

Automatic sizing based on:
- **Signal strength** (composite score)
- **Market volatility** (ATR)
- **Risk limits** (configured max contracts)

### Risk Management

#### Built-in Protections

- **Session P&L Limits**: Stop after daily loss threshold
- **Maximum Positions**: Configurable contract limits
- **Kill Switch**: Emergency stop on consecutive losses
- **Trade Frequency**: Rate limiting to prevent overtrading

#### Dynamic Thresholds

Signal thresholds adjust based on:
- **Trading performance** (raise threshold after losses)
- **Market conditions** (volatility adjustments)
- **Session metrics** (trade count, P&L)

---

## 🔍 Monitoring & Debugging

### Real-time Monitoring

#### Discord Channels
- **#trading-signals**: All buy/sell signals
- **#debug-data**: Minute-by-minute ML decisions
- **#trade-executions**: Order fills and updates
- **#system-status**: Bot health and errors

#### Log Levels

Set `SIGNAL_GEN_LOG` in `.env`:
- **DEBUG**: Detailed technical information
- **INFO**: Normal operation messages
- **WARN**: Warning conditions
- **ERROR**: Critical errors only

### Performance Tracking

The bot automatically tracks:
- **Daily P&L**: Session profit/loss
- **Win Rate**: Percentage of profitable trades
- **Trade Count**: Number of trades per session
- **Signal Accuracy**: ML model performance

---

## 🔧 Troubleshooting

### Common Issues

#### ❌ "License Invalid"
```
Solution: Check LICENSE_TOKEN in .env
Verify subscription at https://aiprediction.us
```

#### ❌ "API Authentication Failed"
```
Solution: Verify TRADOVATE_USERNAME and TRADOVATE_PASSWORD
Ensure you're using API password, not web password
Check TRADOVATE_ENV is set to "demo" or "live"
```

#### ❌ "Failed to Initialize Order Client"
```
Solution: Check API credentials
Verify account has trading permissions
Ensure TRADOVATE_APP_ID, CID, SECRET are correct
```

#### ❌ "Discord Webhook Failed"
```
Solution: Check DISCORD_WEBHOOK_URL format
Ensure webhook is active in Discord
Test webhook manually with curl
```

#### ❌ "Contract Not Found"
```
Solution: Update SIGNAL_GEN_PRIMARY_SYMBOL
Use current contract month (MNQM6 → MNQU6 at rollover)
Verify symbol exists on Tradovate
```

### Debug Mode

Run with detailed logging:
```cmd
set SIGNAL_GEN_LOG=DEBUG
tradovate-signal-gen.exe
```

This provides:
- API request/response details
- ML model predictions
- Signal generation logic
- Trade execution steps

### Log File Analysis

Check the console output for:
- **[heartbeat]**: System is alive
- **[bar 15:30]**: Processing new price bar
- **[signal]**: Signal generated and executed
- **[error]**: Something went wrong

---

## 📞 Support

### Documentation

- **README.md**: Technical overview and configuration
- **DEPLOYMENT.md**: Advanced deployment options
- **USER_GUIDE.pdf**: This guide in PDF format

### Troubleshooting Steps

1. **Check Configuration**: Verify all `.env` settings
2. **Test API Access**: Run in DEBUG mode
3. **Verify License**: Check subscription status
4. **Check Discord**: Ensure webhook is working
5. **Review Logs**: Look for error messages

### Getting Help

For technical support:

1. **Enable DEBUG logging**: `SIGNAL_GEN_LOG=DEBUG`
2. **Capture error messages** from console output
3. **Check Discord messages** for additional context
4. **Note your configuration** (without exposing credentials)

### Best Practices

- **Start with demo account** to test setup
- **Monitor Discord** for first few hours
- **Use small position sizes** initially
- **Keep credentials secure** (never share .env file)
- **Update symbol quarterly** for contract rollovers

---

## 📋 Quick Reference

### Starting the Bot
```cmd
# Navigate to bot directory
cd C:\path\to\tradovate-signal-gen

# Run the bot
tradovate-signal-gen.exe
```

### Stopping the Bot
- Press **Ctrl+C** in console
- Or close the console window

### Configuration Files
- **Main config**: `.env`
- **Backup template**: `.env.example`

### Important URLs
- **API Registration**: https://api.tradovate.com
- **License Purchase**: https://aiprediction.us
- **Discord Webhooks**: Server Settings → Integrations

---

**© 2026 Signal Gen Pro - Distribution Edition**

*This software is provided for authorized users only. Keep your credentials secure and never share your .env configuration file.*