# Deployment Guide - Tradovate Signal Generator Go Edition

This guide covers deployment options for the Tradovate Signal Generator Go Edition.

## 🚀 Quick Start

### Deployment Modes

The signal generator supports two deployment modes:

1. **Extension Mode** - Works with Chrome extension for UI-based trading
2. **Standalone Mode** ✅ - Direct API trading without browser dependency

### 1. Download & Extract
```bash
# Extract the distribution package
unzip tradovate-signal-gen-2.0.0-windows.zip
cd tradovate-signal-gen/
```

### 2. Configure
```bash
# Copy environment template
cp .env.example .env

# Edit configuration (replace with your credentials)
nano .env
```

### 3. Run
```bash
# Windows
./tradovate-signal-gen.exe

# Linux/macOS
./tradovate-signal-gen
```

## 📋 Prerequisites

### System Requirements
- **OS**: Windows 10+, Linux, macOS
- **RAM**: 256MB minimum, 512MB recommended
- **CPU**: Any modern x64 processor
- **Network**: Stable internet connection

### Required Accounts
- **Tradovate Account**: Demo or live trading account
- **API Access**: App registration with Tradovate
- **License**: Valid subscription for ML models

## ⚙️ Configuration

### Environment Variables

Create `.env` file with your settings:

```bash
# Tradovate API
TRADOVATE_ENV=demo
TRADOVATE_USERNAME=your_username
TRADOVATE_PASSWORD=your_password
TRADOVATE_APP_ID=your_app_id
TRADOVATE_CID=your_cid
TRADOVATE_SECRET=your_secret

# License
LICENSE_TOKEN=your_license_token

# Symbol (update quarterly)
SIGNAL_GEN_PRIMARY_SYMBOL=MNQM6

# WebSocket (for browser extension mode only)
SIGNAL_GEN_WS_HOST=127.0.0.1
SIGNAL_GEN_WS_PORT=8765

# Discord integration (for standalone mode debugging)
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_WEBHOOK_URL

# Logging
SIGNAL_GEN_LOG=INFO
```

### Tradovate API Setup

1. **Register Application**
   - Visit https://api.tradovate.com
   - Create new application
   - Note down APP_ID, CID, and SECRET

2. **Enable API Password**
   - Log into Tradovate web platform
   - Go to Account Settings
   - Enable "API Password" feature

3. **Test Connection**
   ```bash
   # Run in debug mode to verify
   SIGNAL_GEN_LOG=DEBUG ./tradovate-signal-gen
   ```

## 🤖 Standalone Mode Deployment

For **standalone operation** (no Chrome extension required):

### Requirements
- Tradovate API credentials (same as above)
- Discord webhook URL (for logging and debugging)
- Valid license for ML models

### Configuration
Add Discord webhook to your `.env`:
```bash
# Discord webhook for standalone logging
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/YOUR_WEBHOOK_URL
```

### Features in Standalone Mode
- ✅ Direct API trading without browser
- ✅ Automatic signal generation and execution
- ✅ Discord notifications for all activity
- ✅ Real-time debugging and monitoring
- ✅ Position management and risk controls

### Discord Setup
1. Create a Discord server or use existing
2. Create a webhook in a channel:
   - Channel Settings → Integrations → Webhooks
   - Copy webhook URL to `.env` file
3. The bot will send:
   - Signal notifications with charts
   - Trade confirmations
   - Debug data every minute
   - Error alerts and status updates

## 🐳 Docker Deployment

### Option 1: Docker Compose (Recommended)

```bash
# Clone or extract source
cd tradovate-signal-gen/

# Configure environment
cp .env.example .env
# Edit .env with your credentials

# Start services
docker-compose up -d

# View logs
docker-compose logs -f signal-generator

# Stop services
docker-compose down
```

### Option 2: Docker Build

```bash
# Build image
docker build -t tradovate-signal-gen .

# Run container
docker run -d \
  --name signal-gen \
  -p 8765:8765 \
  -v $(pwd)/.env:/app/.env:ro \
  -v $(pwd)/models:/app/models:ro \
  -v $(pwd)/data:/app/data \
  tradovate-signal-gen
```

## 🖥️ System Service

### Windows Service

1. **Install NSSM** (Non-Sucking Service Manager)
   ```cmd
   # Download from https://nssm.cc/
   # Extract to C:\nssm\
   ```

2. **Create Service**
   ```cmd
   nssm install TradovateSignalGen
   # Set path to executable
   # Set startup directory
   # Set environment variables
   ```

3. **Start Service**
   ```cmd
   net start TradovateSignalGen
   ```

### Linux Systemd

1. **Create Service File**
   ```bash
   sudo nano /etc/systemd/system/tradovate-signal-gen.service
   ```

   ```ini
   [Unit]
   Description=Tradovate Signal Generator
   After=network.target

   [Service]
   Type=simple
   User=trader
   WorkingDirectory=/opt/tradovate-signal-gen
   ExecStart=/opt/tradovate-signal-gen/tradovate-signal-gen
   EnvironmentFile=/opt/tradovate-signal-gen/.env
   Restart=always
   RestartSec=10

   [Install]
   WantedBy=multi-user.target
   ```

2. **Enable & Start**
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable tradovate-signal-gen
   sudo systemctl start tradovate-signal-gen
   ```

### macOS LaunchAgent

1. **Create Plist**
   ```bash
   nano ~/Library/LaunchAgents/com.signalgen.tradovate.plist
   ```

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN">
   <plist version="1.0">
   <dict>
       <key>Label</key>
       <string>com.signalgen.tradovate</string>
       <key>ProgramArguments</key>
       <array>
           <string>/usr/local/bin/tradovate-signal-gen</string>
       </array>
       <key>WorkingDirectory</key>
       <string>/usr/local/share/tradovate-signal-gen</string>
       <key>RunAtLoad</key>
       <true/>
       <key>KeepAlive</key>
       <true/>
   </dict>
   </plist>
   ```

2. **Load Service**
   ```bash
   launchctl load ~/Library/LaunchAgents/com.signalgen.tradovate.plist
   ```

## 🌐 Cloud Deployment

### VPS Deployment

1. **Provision VPS**
   - 1 vCPU, 1GB RAM minimum
   - Ubuntu 22.04 LTS recommended
   - Static IP address

2. **Setup Environment**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Create user
   sudo useradd -m -s /bin/bash trader
   sudo usermod -aG sudo trader
   
   # Switch to trader user
   sudo su - trader
   ```

3. **Deploy Application**
   ```bash
   # Create directory
   mkdir -p /home/trader/signal-gen
   cd /home/trader/signal-gen
   
   # Upload and extract
   wget https://releases.example.com/tradovate-signal-gen-linux.tar.gz
   tar xzf tradovate-signal-gen-linux.tar.gz
   
   # Configure
   cp .env.example .env
   nano .env
   
   # Setup service
   sudo cp tradovate-signal-gen.service /etc/systemd/system/
   sudo systemctl enable tradovate-signal-gen
   sudo systemctl start tradovate-signal-gen
   ```

### AWS EC2

1. **Launch Instance**
   - t3.micro or larger
   - Amazon Linux 2 or Ubuntu
   - Security group: port 22 (SSH) only

2. **Deploy with User Data**
   ```bash
   #!/bin/bash
   yum update -y
   useradd trader
   cd /home/trader
   wget https://releases.example.com/tradovate-signal-gen-linux.tar.gz
   tar xzf tradovate-signal-gen-linux.tar.gz
   chown -R trader:trader /home/trader
   # Configure .env file
   # Setup systemd service
   ```

## 🔒 Security

### Firewall Configuration

```bash
# Ubuntu/Debian
sudo ufw allow 22/tcp     # SSH
sudo ufw allow 8765/tcp   # WebSocket (if needed externally)
sudo ufw enable

# CentOS/RHEL
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --permanent --add-port=8765/tcp
sudo firewall-cmd --reload
```

### SSL/TLS (Optional)

For external WebSocket access, use reverse proxy:

```nginx
# /etc/nginx/sites-available/signal-gen
server {
    listen 443 ssl;
    server_name signals.yourdomain.com;
    
    ssl_certificate /etc/letsencrypt/live/signals.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/signals.yourdomain.com/privkey.pem;
    
    location / {
        proxy_pass http://127.0.0.1:8765;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

## 📊 Monitoring

### Health Checks

```bash
# Check process
ps aux | grep tradovate-signal-gen

# Check port
netstat -tlnp | grep 8765

# Check logs
tail -f /var/log/signal-gen.log

# WebSocket test
wscat -c ws://localhost:8765
```

### Prometheus Metrics (Optional)

Add to docker-compose.yml:
```yaml
# Enable monitoring profile
docker-compose --profile monitoring up -d
```

Access dashboards:
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin/admin)

## 🔄 Updates

### Manual Update

```bash
# Stop service
sudo systemctl stop tradovate-signal-gen

# Backup configuration
cp .env .env.backup

# Download new version
wget https://releases.example.com/tradovate-signal-gen-linux.tar.gz
tar xzf tradovate-signal-gen-linux.tar.gz

# Restore configuration
cp .env.backup .env

# Start service
sudo systemctl start tradovate-signal-gen
```

### Docker Update

```bash
# Pull new image
docker-compose pull

# Restart with new image
docker-compose up -d
```

## 🆘 Troubleshooting

### Common Issues

1. **License Invalid**
   ```bash
   # Check license status
   curl -s "https://excellgen.com/webhk/license/?token=YOUR_TOKEN"
   ```

2. **API Connection Failed**
   ```bash
   # Test API credentials
   SIGNAL_GEN_LOG=DEBUG ./tradovate-signal-gen
   ```

3. **Port Already in Use**
   ```bash
   # Find process using port
   lsof -i :8765
   # Kill process if needed
   kill -9 PID
   ```

4. **Permission Denied**
   ```bash
   # Fix file permissions
   chmod +x tradovate-signal-gen
   chown trader:trader -R /path/to/signal-gen/
   ```

### Log Analysis

```bash
# Show recent logs
journalctl -u tradovate-signal-gen -f

# Show errors only
journalctl -u tradovate-signal-gen -p err

# Show logs from specific time
journalctl -u tradovate-signal-gen --since "2024-01-01 10:00"
```

## 📞 Support

For deployment assistance:

1. **Check Documentation**: Review README.md and logs
2. **Debug Mode**: Run with `SIGNAL_GEN_LOG=DEBUG`
3. **License Issues**: Verify subscription status
4. **API Problems**: Check Tradovate credentials

---

**© 2026 Signal Gen Pro - Distribution Edition**