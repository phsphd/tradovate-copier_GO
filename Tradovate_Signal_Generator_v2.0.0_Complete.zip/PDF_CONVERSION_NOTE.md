# PDF Conversion Instructions

The USER_GUIDE.md file can be converted to PDF using several methods:

## Method 1: Using VS Code (Recommended)
1. Install "Markdown PDF" extension in VS Code
2. Open USER_GUIDE.md in VS Code
3. Press Ctrl+Shift+P
4. Type "Markdown PDF: Export (pdf)"
5. Save as USER_GUIDE.pdf

## Method 2: Using Pandoc (If Available)
```bash
pandoc USER_GUIDE.md -o USER_GUIDE.pdf --pdf-engine=xelatex -V geometry:margin=1in
```

## Method 3: Using Online Converter
1. Visit https://www.markdowntopdf.com/
2. Copy USER_GUIDE.md content
3. Convert and download PDF

## Method 4: Using Chrome/Edge
1. Open USER_GUIDE.md in GitHub or VS Code preview
2. Press Ctrl+P (Print)
3. Select "Save as PDF"
4. Configure layout and save

The markdown version is fully formatted and ready for PDF conversion.