# How to Create PDF User Guide

I've created `USER_GUIDE.html` which can be easily converted to PDF. Here are several methods:

## 🌐 Method 1: Browser Print-to-PDF (Easiest)

1. **Open** `USER_GUIDE.html` in Chrome, Edge, or Firefox
2. **Press** `Ctrl+P` (Print)
3. **Change destination** to "Save as PDF"
4. **Adjust settings**:
   - Paper size: A4 or Letter
   - Margins: Default
   - Background graphics: ✅ Enabled
5. **Click** "Save" → name it `USER_GUIDE.pdf`

## 📝 Method 2: VS Code Extension

1. **Install** "Markdown PDF" extension in VS Code
2. **Open** `USER_GUIDE.md` in VS Code
3. **Press** `Ctrl+Shift+P`
4. **Type** "Markdown PDF: Export (pdf)"
5. **Save** as `USER_GUIDE.pdf`

## 🖥️ Method 3: Online HTML to PDF Converter

1. **Visit** https://www.ilovepdf.com/html-to-pdf
2. **Upload** `USER_GUIDE.html` 
3. **Convert** and download PDF

## 🔧 Method 4: Pandoc (If Available)

```bash
pandoc USER_GUIDE.md -o USER_GUIDE.pdf --pdf-engine=xelatex -V geometry:margin=1in
```

## 📊 Recommended Output Settings

- **Format**: PDF
- **Paper**: A4 or US Letter
- **Margins**: 1 inch all sides
- **Orientation**: Portrait
- **Quality**: High (300 DPI)
- **Background**: Include graphics and colors

## 📁 Files Available

- `USER_GUIDE.md` - Markdown source
- `USER_GUIDE.html` - Styled HTML version (best for PDF conversion)
- `CREATE_PDF_GUIDE.md` - This instruction file

The HTML version is professionally styled with:
- Clean typography
- Color-coded sections
- Proper page breaks
- Table of contents links
- Responsive layout