# Ported Features (2026-04-23)

Features copied from the Chrome extension (`C:\Paul\IT\IT\tradovate_trade_copier\extension\`) to this Go bot, per user request. **Group auto-create is deliberately NOT ported** — the Chrome-side code for it is unproven (Tradovate's drag-and-drop UI prevents automated group creation, see `tradovate_trade_copier/extension/KNOWN_ISSUES.md`).

## 1. Multi-account copying

Already supported by design. Each follower in `config.FollowerAccounts` is a separate `Account` record with its own `username`, `password`, and `account_id`. To trade one Tradovate login across multiple sub-accounts, list the same username/password with different `account_id`s — the bot authenticates once per (username, accountID) pair and maintains a dedicated WS client per follower account.

`replicator.ReplicatePlace` now **skips `follower.AccountID == leaderOrder.AccountID`** to prevent the leader's own account from being double-populated (mirrors `tradovate_trade_copier/extension@v1.1.1`).

## 2. Copy limit orders

Already worked via existing `leaderOrder.OrderType` / `leaderOrder.Price` / `leaderOrder.StopPrice` forwarding. The fix in this port:

- `Monitor.handleMessage` no longer replicates on every `Filled|Working` status update. Instead it calls `tracker.ClassifyLeaderEvent(...)` which returns an `Intent`:
  - `IntentPlace` only on the FIRST time we see an orderID
  - `IntentSkip` on subsequent state-change noise (partial fills, Filled-ack of a Working order, etc.)

Without this, a Limit order would be replicated twice — once when it appeared as `Working`, once when it became `Filled`.

## 3. Move limit orders

**New capability.** When the leader modifies an existing open limit/stop order (price or qty change), the bot now:

1. `tracker.ClassifyLeaderEvent` returns `IntentModify` because the orderID is known, status is `Working`, and price/qty diverges from the last-seen state.
2. `Replicator.ReplicateModify(leaderOrderID, newPrice, newStopPrice, newQty)` looks up the `leaderOrderID -> {followerAccountID: followerOrderID}` map from `OrderTracker`.
3. For each mapped follower order, sends `order/modifyorder` via that follower's WS with the follower's own orderID.

The mapping is built at placement time: `Replicator.placeOrder` calls `tracker.RegisterPendingPlacement(reqID, leaderOrderID, followerAccountID)` before sending. The follower's WS client has a `ResponseHandler` installed in `ConnectFollowers` that watches for `{ "i": reqID, "s": 200, "d": { "orderId": N } }` and calls `tracker.BindFollowerOrder(reqID, followerOrderID)`, completing the chain.

## 4. Cancel limit orders

**New capability.** When the leader cancels a working limit/stop order (status transitions to `Canceled` / `Rejected` / `Expired`):

1. `tracker.ClassifyLeaderEvent` returns `IntentCancel` for already-replicated orders.
2. `Replicator.ReplicateCancel(leaderOrderID)` sends `order/cancelorder` to each mapped follower orderID in parallel.
3. After propagation, `tracker.DropLeaderOrder(leaderOrderID)` removes the state so late events for the same orderID (late fills after cancel, etc.) don't re-trigger anything.

## Files added / modified

- **`order_tracker.go`** *(new)* — `OrderTracker` struct; intent classifier; pending-request / orderID bookkeeping; periodic housekeeping.
- **`websocket.go`** *(modified)* — added `responseHandler` callback + `SetResponseHandler` + `dispatchResponse`. Called inside the read loop on every message so the follower replicator can bind returned orderIds.
- **`replicator.go`** *(rewritten)* — split into `ReplicatePlace / ReplicateModify / ReplicateCancel`; wires the tracker; skips the leader's own accountID from the follower fan-out; adds `nextReqID()` monotonic request-ID generator starting at 10000.
- **`monitor.go`** *(modified)* — `handleMessage` now routes via `tracker.ClassifyLeaderEvent` and dispatches to `ReplicatePlace/Modify/Cancel`.

## Build

```
go build -o tradovate_copier.exe \
    main.go monitor.go replicator.go websocket.go config.go auth.go order_tracker.go
```

(The `test_*.go` files in the repo also declare `package main` and will break `go build ./...` — pre-existing, unrelated to this port.)

## Not ported (intentional)

- **Account-group auto-create / auto-repair.** Relies on Tradovate's DOM which has drifted; the Chrome version lands in the `TRADOVATE_DND_UI` disabled state on current UI. Headless Go can't drive that dialog at all.
- **Heikin-Ashi trigger helpers / DeepChart** — trading-logic features that aren't part of the copy-trader core.
- **License/auth-check layer** — the Go bot uses plain Tradovate credentials, no separate license server.

## What still NEEDS manual attention

- **Config:** you must populate `config.json` with leader + follower account IDs (Tradovate numeric IDs, not usernames). The `_init` flag generates an example.
- **OrderEvent fields:** the current `ParseOrderEvent` assumes the order event comes as the 4th line of a Tradovate WS frame. If Tradovate adds wrappers (e.g. array envelopes), that parser will need an update. This was pre-existing.
- **WS reconnection:** the existing reconnect logic doesn't re-subscribe to user events; a long disconnect will silently stop copying. Not worse than it was before the port, but worth flagging.
